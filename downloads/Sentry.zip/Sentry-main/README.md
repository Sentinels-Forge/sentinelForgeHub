# Sentry
Antivirus Software to stop unwanted programs from running.
# To use:
In order to make this work, follow the following steps:\
&nbsp; &nbsp; 1. Download Sentry on an Administrator\
&nbsp; &nbsp; 2. Go to Downloads\
&nbsp; &nbsp; 3. Move the "Sentry-main" folder to Documents\
**Important!**\
&nbsp; &nbsp; 4. Rename the "Sentry-main" to "Sentry"\
**Important!**\
Do NOT put the Sentry folder in any other folder, other than Documents!\
To use, make sure to have Python installed, and open Powershell. Make sure you are in the directory of "Secure Files", and do "python main.py" in Powershell (Must be in correct directory)\
<br>
To terminate the program, either press and hold "]", terminate Powershell, or kill it in the Task Manager.
# Roadmap
1.0.0 -- <s>Successfully saves downloads and updates logs</s>\
1.1.0 -- <s>Successfully compares the downloads.txt to the current downloads to check for new items</s>\
1.1.1 -- <s>Successfully prevents unwanted downloads (hopefully pauses the moment it realizes)</s> **Current Version**

2.0.0 -- Has a GUI for easy access and control
